package com.mycompany.posttest1.model;

public abstract class Barang implements Penilaian {
    // Properties (encapsulation)
    private int id;
    private String nama;
    private String kategori;
    private String asal;
    private int tahun;
    private String material;
    private String kondisi;
    private String sumber;          
    private double hargaPerolehan;

    // Constructor
    public Barang(int id, String nama, String kategori, String asal, int tahun,
                  String material, String kondisi, String sumber, double hargaPerolehan) {
        this.id = id;
        this.nama = nama;
        this.kategori = kategori;
        this.asal = asal;
        this.tahun = tahun;
        this.material = material;
        this.kondisi = kondisi;
        this.sumber = sumber;
        this.hargaPerolehan = hargaPerolehan;
    }

    // Getters & Setters (encapsulation)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public String getAsal() { return asal; }
    public void setAsal(String asal) { this.asal = asal; }

    public int getTahun() { return tahun; }
    public void setTahun(int tahun) { this.tahun = tahun; }

    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }

    public String getKondisi() { return kondisi; }
    public void setKondisi(String kondisi) { this.kondisi = kondisi; }

    public String getSumber() { return sumber; }
    public void setSumber(String sumber) { this.sumber = sumber; }

    public double getHargaPerolehan() { return hargaPerolehan; }
    public void setHargaPerolehan(double hargaPerolehan) { this.hargaPerolehan = hargaPerolehan; }

    public String infoSingkat() {
        return String.format("#%d %s (%s) | asal: %s | sumber: %s",
                id, nama, kategori, asal, sumber);
    }

    public String infoSingkat(boolean tampilHarga) {
        if (!tampilHarga) return infoSingkat();
        return infoSingkat() + String.format(" | harga: Rp%,.0f", hargaPerolehan);
    }

    @Override
    public double estimasiNilai(double faktorKondisi) {
        return Math.max(0, this.hargaPerolehan * faktorKondisi);
    }

    public abstract double hitungAsuransi();
    public abstract String getTipe();
}