package com.mycompany.posttest1.model;

public class barangWarisan extends Barang {
    public barangWarisan(int id, String nama, String kategori, String asal, int tahun,
                         String material, String kondisi, String sumber, double hargaPerolehan) {
        super(id, nama, kategori, asal, tahun, material, kondisi, sumber, hargaPerolehan);
    }

    @Override
    public double hitungAsuransi() {
        // Premi 0.8% dari estimasi nilai normal (faktor 1.0)
        return estimasiNilai(1.0) * 0.008;
    }

    @Override
    public String getTipe() { return "WARISAN"; }

    @Override
    public String infoSingkat() {
        return super.infoSingkat() + " | tipe: WARISAN";
    }
}
